<?php

defined('_JEXEC') or die;
 
/**
* Themler plugin
*/

class plgContentThemlercontent extends JPlugin
{
    public function onContentPrepare($context, &$row, &$params, $page = 0)
	{
        if ('' != JRequest::getVar('template', '') && 'on' == JRequest::getVar('is_preview', ''))
            return;

        $lib = JPATH_PLUGINS . '/content/themlercontent/lib';

        $doc = JFactory::getDocument();

        $jquery = $this->params->get('jquery', '0');
        if ($jquery == '1') {
            $doc->addScript(JURI::root(true) . '/plugins/content/themlercontent/lib/beforejq.js');
            $doc->addScript(JURI::root(true) . '/plugins/content/themlercontent/lib/jquery.js');
            $doc->addScript(JURI::root(true) . '/plugins/content/themlercontent/lib/afterjq.js');
        }
        $bootstrapjs = $this->params->get('bootstrapjs', '0');
        if ($bootstrapjs == '1') {
            $doc->addScript(JURI::root(true) . '/plugins/content/themlercontent/lib/bootstrap.min.js');
        }
        $bootstrapcss = $this->params->get('bootstrapcss', '0');
        if ($bootstrapcss == '1') {
            $doc->addStyleSheet(JURI::root(true) . '/plugins/content/themlercontent/lib/bootstrap.css');
        }

        $scpath = $lib . '/Shortcodes.php';
        require_once $scpath;
        $row->text = DesignerShortcodes::process($row->text);
        
        return;
    }
}