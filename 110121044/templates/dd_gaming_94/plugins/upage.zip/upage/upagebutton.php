<?php

defined('_JEXEC') or die;

class PlgButtonUpagebutton extends JPlugin
{

    private $_cmsPath;
    private $_isAdmin;

    public function __construct(& $subject, $config)
    {
        parent::__construct($subject, $config);
        $this->loadLanguage();

        $app = JFactory::getApplication();
        $this->_isAdmin = $app->isAdmin();
        $this->_cmsPath = $this->_isAdmin ? dirname(dirname(JPATH_THEMES)) : dirname(JPATH_THEMES);
    }

    public function onDisplay($name)
    {
        $app = JFactory::getApplication('administrator');
        $domain = JRequest::getCmd('domain', '');
        if ($domain == '')
            return;
        $option = JRequest::getCmd('option');
        $aid = JRequest::getCmd('id', '');
        if(!in_array($option, array('com_content')) || '' == $aid || !$this->_isAdmin)
            return;

        $adminThemeDir = JPATH_ADMINISTRATOR . '/templates/' . $app->getTemplate();
        $lib = JPATH_PLUGINS . '/editors-xtd/upagebutton/lib';

        jimport('joomla.filesystem.file');
        jimport('joomla.filesystem.folder');
        require_once $lib . '/classes/UpagePostManager.php';
        UpageSectionsManager::buildUpageSectionsTable();

        if ('' !== JRequest::getCmd('editor', '')) {
            JFile::copy($lib . '/view/upage.php', $adminThemeDir . '/upage.php');
            $app->input->set('tmpl', 'upage');
            return;
        }

        $message = '';
        $currentUrl = '';
        if (themlerShortCodesPluginIsInstalled()) {
            $currentUrl = JFactory::getURI()->toString() . '&editor=1/#/site/1/page/' . $aid . '/section/' . md5(round(microtime(true)));
        } else {
            $message = JText::_('Themler Shortcodes Plugin are not installed');
        }

        $screenshotsContent = UpageSectionsManager::getScreenshots();

        $js = <<<EOF
jQuery(function($) {
    renderSectionsScreenshots();
});

function runUpage()
{
    var url = '$currentUrl';
    if (url){
        jQuery('body')
        .prepend('<iframe src="$currentUrl" id="upage-iframe" width="100%" height="100%" frameborder="0" allowtransparency="true" style="position: fixed;z-index: 9999999;width: 100%;height: 100%;top:0;left:0;bottom: 0;"></iframe>')
        .append('<style id="upage-editor-styles">body {overflow:hidden;}</style>');
        //window.open(url, '_blank');
    } else {
        alert('$message');
    }

}

function renderSectionsScreenshots()
{
    (function($){
        $('fieldset.adminform').before($screenshotsContent);
        $('#upage-preview a').click(function(e) {
            e.preventDefault();
            runUpage();
        });
    })(jQuery);
}

function onSavingStart() {
    jQuery('body').append(
        '<div id="upage-saving-wrap">' +
        '   <div id="upage-saving-bg"></div>' +
        '   <div id="upage-saving-content">' +
        '       <div class="loader">' +
        '           <div class="upage-saving-wrap">' +
        '               <div class="bar1"></div><div class="bar2"></div><div class="bar3"></div><div class="bar4"></div><div class="bar5"></div><div class="bar6"></div><div class="bar7"></div><div class="bar8"></div><div class="bar7"></div><div class="bar8"></div><div class="bar9"></div><div class="bar10"></div>' +
        '           </div>' +
        '       </div>' +
        '       <div class="upage-saving-text">Saving...</div>' +
        '   </div>' +
        '</div>');
}

function onSavingEnd(hasChanges) {
    if (hasChanges) {
        window.location.reload();
        return;
    }

    jQuery('#upage-saving-wrap').remove();
    jQuery('#upage-editor-styles').remove();
    jQuery('#upage-iframe').remove();
}

function upageEventListener(event) {
    var data;
    try {
        data = JSON.parse(event.data);
    } catch(e) {
        console.warn(e);
        return;
    }

    if (data.message === 'savingStart') {
        onSavingStart();
    } else if (data.message === 'savingEnd') {
        onSavingEnd(data.hasChanges);
    }
}

if (window.addEventListener) {
    window.addEventListener("message", upageEventListener);
} else {
    window.attachEvent("onmessage", upageEventListener); // IE8
}

EOF;
        $style = <<<EOF
#upage-saving-bg {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: #000;
    opacity: 0.7;
    z-index: 1000010;
}

#upage-saving-content * {
    z-index: 1000111;
}

#upage-saving-content {
    position: fixed;
    left: 50%;
    overflow: hidden;
    top: 50%;
    z-index: 1000011;

    width: 200px;
    height: 250px;
    margin-left: -100px;
    margin-top: -200px;
}

#upage-saving-content .loader {
    position: absolute;
    left: 50%;
    top: 50%;
    margin-top:-50px;
    margin-left:-50px;
}

#upage-saving-content .upage-saving-text {
    position: relative;
    top: 200px;
    font-size: 22px;
    text-align: center;
    color: white;
}

#upage-saving-content .upage-saving-wrap {
    position:absolute;
    width:100px;
    height:100px;
    float:left;

    -webkit-animation-name: rotateThis;
    -webkit-animation-duration:3s;
    -webkit-animation-iteration-count:infinite;
    -webkit-animation-timing-function:linear;

    -moz-transform:scale(0.3);
    -o-transform:scale(0.3);
}

#upage-saving-content .upage-saving-wrap div {
    width: 10px;
    height: 30px;
    background: white;
    position: absolute;
    top: 35px;
    left: 45px;

    border-radius: 50px;
    -moz-border-radius-bottomleft:50px;
    -moz-border-radius-bottomright:50px;
    -moz-border-radius-topleft:50px;
    -moz-border-radius-topright:50px;
}

@-webkit-keyframes rotateThis {
from { -webkit-transform:scale(0.6) rotate(0deg); }
    to 	 { -webkit-transform:scale(0.6) rotate(360deg); }
}

#upage-saving-content .bar1 {
    -o-transform:rotate(0deg) translate(0, -100px);opacity:0.1;
    -moz-transform:rotate(0deg) translate(0, -100px);opacity:0.1;
    -webkit-transform:rotate(0deg) translate(0, -100px);opacity:0.1;
}
#upage-saving-content .bar2 {
    -o-transform:rotate(36deg) translate(0, -100px);opacity:0.2;
    -moz-transform:rotate(36deg) translate(0, -100px);opacity:0.2;
    -webkit-transform:rotate(36deg) translate(0, -100px);opacity:0.2;
}
#upage-saving-content .bar3 {
    -o-transform:rotate(72deg) translate(0, -100px);opacity:0.3;
    -moz-transform:rotate(72deg) translate(0, -100px);opacity:0.3;
    -webkit-transform:rotate(72deg) translate(0, -100px);opacity:0.3;
}
#upage-saving-content .bar4 {
    -o-transform:rotate(108deg) translate(0, -100px);opacity:0.4;
    -moz-transform:rotate(108deg) translate(0, -100px);opacity:0.4;
    -webkit-transform:rotate(108deg) translate(0, -100px);opacity:0.4;
}
#upage-saving-content .bar5 {
    -o-transform:rotate(144deg) translate(0, -100px);opacity:0.5;
    -moz-transform:rotate(144deg) translate(0, -100px);opacity:0.5;
    -webkit-transform:rotate(144deg) translate(0, -100px);opacity:0.5;
}
#upage-saving-content .bar6 {
    -o-transform:rotate(180deg) translate(0, -100px);opacity:0.6;
    -moz-transform:rotate(180deg) translate(0, -100px);opacity:0.6;
    -webkit-transform:rotate(180deg) translate(0, -100px);opacity:0.6;
}
#upage-saving-content .bar7 {
    -o-transform:rotate(216deg) translate(0, -100px);opacity:0.7;
    -moz-transform:rotate(216deg) translate(0, -100px);opacity:0.7;
    -webkit-transform:rotate(216deg) translate(0, -100px);opacity:0.7;
}
#upage-saving-content .bar8 {
    -o-transform:rotate(252deg) translate(0, -100px);opacity:0.8;
    -moz-transform:rotate(252deg) translate(0, -100px);opacity:0.8;
    -webkit-transform:rotate(252deg) translate(0, -100px);opacity:0.8;
}
#upage-saving-content .bar9 {
    -o-transform:rotate(288deg) translate(0, -100px);opacity:0.9;
    -moz-transform:rotate(288deg) translate(0, -100px);opacity:0.9;
    -webkit-transform:rotate(288deg) translate(0, -100px);opacity:0.9;
}
#upage-saving-content .bar10 {
    -o-transform:rotate(324deg) translate(0, -100px);opacity:1;
    -moz-transform:rotate(324deg) translate(0, -100px);opacity:1;
    -webkit-transform:rotate(324deg) translate(0, -100px);opacity:1;
}
EOF;

        $doc = JFactory::getDocument();
        $doc->addScriptDeclaration($js);
        $doc->addStyleDeclaration($style);

        $button = new JObject;
        $button->set('modal', false);
        $button->set('class', 'btn upage-button');
        $button->set('title', JText::_('PLG_EDITORS-XTD_UPAGEBUTTON_BUTTON_TITLE'));
        $button->set('text', JText::_('PLG_EDITORS-XTD_UPAGEBUTTON_BUTTON_TEXT'));
        $button->set('name', 'edit');
        $button->set('onclick', 'runUpage();return false;');
        $button->link = '#';

        return $button;
    }
}